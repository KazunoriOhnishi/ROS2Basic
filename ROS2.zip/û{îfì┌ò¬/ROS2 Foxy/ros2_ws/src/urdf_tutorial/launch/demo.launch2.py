import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():

  use_sim_time = LaunchConfiguration('use_sim_time', default='true')
#  urdf_file_name = 'basic1.urdf'
  urdf_file_name = '04-materials.urdf'
#  urdf_file_name = 'r2d2.urdf.xml'
#  urdf_file_name = 'pan_tilt.urdf'
#  urdf_file_name = 'stl_body.urdf'
#  urdf_file_name = 'dae_body.urdf'
#  urdf_file_name = 'stl_body.urdf'
#  urdf_file_name = 'my_robot.urdf'
#  urdf_file_name = 'jetbot.urdf'


  print("urdf_file_name : {}".format(urdf_file_name))

  urdf = os.path.join(
      get_package_share_directory('urdf_tutorial'),urdf_file_name)

  config_file_name = '/home/nx/ros2_ws/src/urdf_tutorial/rviz/robot111.rviz'

  rviz_config = os.path.join(
      get_package_share_directory('urdf_tutorial'),
      config_file_name)

  print("config_file_name : {}".format(config_file_name))

  return LaunchDescription([
      DeclareLaunchArgument(
          'use_sim_time',
          default_value='false',
          description='Use simulation (Gazebo) clock if true'),
      Node(
          package='joint_state_publisher_gui',
          node_executable='joint_state_publisher_gui',
          name='joint_state_publisher_gui',
          output='screen',
          parameters=[{'use_sim_time': use_sim_time}],
          arguments=[urdf]),

      Node(
          package='robot_state_publisher',
          node_executable='robot_state_publisher',
          name='robot_state_publisher',
          output='screen',
          parameters=[{'use_sim_time': use_sim_time}],
          arguments=[urdf]),

      Node(
          package='rviz2',
          node_executable='rviz2',
          name='rviz2',
          output='screen',
          arguments=['-d', rviz_config]),
  ])

