# rosjp_ros2_basics

ROSJPのROS 2講習会ようのサンプルコードです。
