#include <stdio.h>
#include <opencv2/opencv.hpp>

using namespace std;

int main(void) {
  cout << "opencv test" << endl;
  cv::Mat img = cv::imread("/home/nx/work/cpp_cv/orange.jpg");
  cv::imshow("img", img);
  cv::waitKey();
  return 0;
} 

