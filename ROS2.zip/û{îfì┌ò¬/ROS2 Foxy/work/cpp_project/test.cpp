#include "test.hpp"
using namespace std;

int main(void){
    int a = 1;
    int b = 2;
    int c = a + b;
    cout << "test:" << c << endl;
    return 0;
}

