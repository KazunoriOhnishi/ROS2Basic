control_msgs
===========

See [control_msgs documentation](http://wiki.ros.org/control_msgs) on ros.org

### Build Status

Kinetic | Melodic | Crystal | Dashing | Eloquent | Foxy
 ------ | ------ | ------ | ------ | ------ | ------
[![Build Status](https://travis-ci.org/ros-controls/control_msgs.png?branch=kinetic-devel)](https://travis-ci.org/ros-controls/control_msgs) | [![Build Status](https://travis-ci.org/ros-controls/control_msgs.png?branch=kinetic-devel)](https://travis-ci.org/ros-controls/control_msgs) | [![Build Status](https://travis-ci.org/ros-controls/control_msgs.png?branch=crystal-devel)](https://travis-ci.org/ros-controls/control_msgs) | [![Build Status](https://travis-ci.org/ros-controls/control_msgs.png?branch=crystal-devel)](https://travis-ci.org/ros-controls/control_msgs) | [![Build Status](https://travis-ci.org/ros-controls/control_msgs.png?branch=crystal-devel)](https://travis-ci.org/ros-controls/control_msgs) | [![Build Status](https://api.travis-ci.org/ros-controls/control_msgs.png?branch=foxy-devel)](https://travis-ci.org/ros-controls/control_msgs)  
