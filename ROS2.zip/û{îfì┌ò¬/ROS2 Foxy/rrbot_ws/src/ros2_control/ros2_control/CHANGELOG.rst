^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ros2_control
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.1 (2021-03-02)
------------------

0.2.0 (2021-02-26)
------------------

0.1.6 (2021-02-05)
------------------

0.1.5 (2021-02-04)
------------------

0.1.4 (2021-02-03)
------------------
* Add test assets package (`#289 <https://github.com/ros-controls/ros2_control/issues/289>`_)
* Contributors: Denis Štogl

0.1.3 (2021-01-21)
------------------

0.1.2 (2021-01-06)
------------------

0.1.1 (2020-12-23)
------------------
* Remove transmission_interface from release, add ros2cli to ros_control (`#280 <https://github.com/ros-controls/ros2_control/issues/280>`_)
  * Remove transmission_interface from release, add ros2cli to ros_control
  metapackage
  * patch
* Contributors: Bence Magyar

0.1.0 (2020-12-22)
------------------
* Remove controller parameter server (`#113 <https://github.com/ros-controls/ros2_control/issues/113>`_)
* Add ros2_control metapackage
* Contributors: Anas Abou Allaban, Bence Magyar, Karsten Knese, Matt Reynolds
