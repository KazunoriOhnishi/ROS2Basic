robot agnostic hardware_interface package.
This package will eventually be moved into its own repo.
